#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "fwding.h"

#define SWVERSION "v0.1 alpha"
#define SWRELEASEDATE "January 2013"

// "fwding" attempts to calculate the forwarding delay for frames containing a Spirent signature.
// Written by Foeh Mannay
// Please refer to http://networkbodges.blogspot.com for more information about this tool.
// This software is released under the Modified BSD license.

params_t *parseParams(int argc, char *argv[]){
	// Returns a struct with various parameters or NULL if invalid
	params_t *parameters = (params_t*)malloc(sizeof(params_t));
	if(parameters == NULL) return(NULL);

	// There must be 1 parameter
	if(argc != 2) return(NULL);

	// Set some defaults
	parameters->capfile = NULL;

	// Look for the various flags, then store the corresponding value
	parameters->capfile = argv[1];

	// If the input files still aren't set, bomb
	if(parameters->capfile == NULL) return(NULL);

	return(parameters);
}

sig_t *parse_pcap(FILE *capfile){
	char 				*memblock = NULL;
	guint32				caplen = 0,
					fnum = 1;
	sig_t				*head = NULL,
					*tail = NULL,
					*s = NULL;
	
	// Start parsing the capture file:
	rewind(capfile);
	clearerr(capfile);
	memblock = (char*)malloc(sizeof(pcap_hdr_t));
	if(memblock == NULL){
		printf("Insufficient memory to load capture header.\n");
		return(NULL);
	}
	// Read the pcap header
	if(fread (memblock, 1, sizeof(pcap_hdr_t), capfile) != sizeof(pcap_hdr_t)){
		printf("Truncated capture file header - aborting.\n");
		free(memblock);
		return(NULL);
	}
	// Verify the magic number in the header indicates a pcap file
	if(((pcap_hdr_t*)memblock)->magic_number != 2712847316){
		printf("\nError!\nThis is not a valid pcap file. If it has been saved as pcap-ng\nconsider converting it to original pcap format with tshark or similar.\n");
		free(memblock); 
		return(NULL);
	}
	
	// Read in the packets and search for any CHAP. Store the challenges and responses in a list.
	while(feof(capfile) | ferror(capfile) == 0){
		// Generate a sig record template ready to use
		s = (sig_t*)malloc(sizeof(sig_t));
		if(s == NULL){
			printf("Error: could not allocate memory for signature template!\n");
			return(NULL);
		}
		s->next = NULL;
		s->frameno = fnum++;
		
		free(memblock);
		// Get the packet record header and examine it for the packet size
		memblock = malloc(sizeof(pcaprec_hdr_t));
		if(memblock == NULL){
			printf("Error: Could not allocate memory for pcap record header!\n");
			return(NULL);
		}
		if(fread (memblock, 1, sizeof(pcaprec_hdr_t), capfile) != sizeof(pcaprec_hdr_t)){
//			printf("Error: Truncated pcap file reading record header!\n");
			break;
		}
		caplen = ((pcaprec_hdr_t*)memblock)->incl_len;
		s->ts_sec = ((pcaprec_hdr_t*)memblock)->ts_sec;
		s->ts_usec = ((pcaprec_hdr_t*)memblock)->ts_usec;
		
		free(memblock);
		memblock = (char*)malloc(caplen);
		if(memblock == NULL){
			printf("Error: Could not allocate memory for pcap record header!\n");
			return(NULL);
		}
		// Get the actual packet data and attempt to parse it
		if(fread (memblock, 1, caplen, capfile) != caplen){
			printf("Error: Truncated pcap file reading capture!\n");
			break;
		}
		
		if(caplen < 20){
			free(s);
			continue;
		}
		memcpy(s->sig, (memblock + caplen - 20), 20);
		s->next = NULL;
		
		// Add the new item to the list
		if(head == NULL){
			head = s;
		} else{
			tail->next = s;
		}
		tail = s;
	}
	free(memblock);

	return(head);
}

void dump_latencies(sig_t *stamps){
	sig_t	*current = stamps;
	sig_t	*hunt;
	
	for (current = stamps; current !=NULL; current = current->next){
		for(hunt = current->next; hunt !=NULL; hunt = hunt->next){
			if(memcmp(current->sig, hunt->sig, 20) == 0){
				if(hunt->ts_usec < current->ts_usec){
					hunt->ts_usec += 1000000;
					hunt->ts_sec -= 1;
				}
				printf("%u, %u.%06u, %u, %u.%06u, %u.%06u\n", current->frameno, current->ts_sec, current->ts_usec, hunt->frameno, hunt->ts_sec, hunt->ts_usec, hunt->ts_sec - current->ts_sec, hunt->ts_usec - current->ts_usec);
				break;
			}
		}
	}
	return;
}

int main(int argc, char *argv[]){
// The main function basically just calls other functions to do the work.
	params_t			*parameters = NULL;
	FILE				*capfile = NULL;
	sig_t				*stamps = NULL;
	
	// Parse our command line parameters and verify they are usable. If not, show help.
	parameters = parseParams(argc, argv);
	if(parameters == NULL){
		printf("fwding: Calculates the forwarding delay for frames with a Spirent signature\nVersion %s, %s\n\n", SWVERSION, SWRELEASEDATE);
		printf("Usage:\n");
		printf("%s capfile\n\n",argv[0]);
		printf("Where capfile is a tcpdump-style .cap file containing copies of the same frames\n");
		printf("before and after routing through a device.\n");
		return(1);
	}
	
	// Attempt to open the capture file and word list:
	capfile = fopen(parameters->capfile,"rb");
	if (capfile == NULL) {
		printf("\nError!\nUnable to open capture file!\n");
		return(1);
	}
	
	// Parse the pcap file and store any signatures & timestamps found in the list:
	stamps = parse_pcap(capfile);
	fclose(capfile);
	
	// Finally, dump out the time deltas.
	if(stamps == NULL){
		printf("No timestamps could be gathered.\n");
		return(1);
	}
	printf("Arrival Frame Number, Arrival Time, Departure Frame Number, Departure Time, Forwarding Delay\n");
	dump_latencies(stamps);
	return(0);
}

